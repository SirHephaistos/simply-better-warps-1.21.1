package as.sirhephaistos;

import as.sirhephaistos.simplybetter.core.db.*;
import as.sirhephaistos.simplybetter.library.*;
import lombok.Getter;
import net.fabricmc.api.DedicatedServerModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.List;
import java.util.Optional;

public class SimplyBetterCoreServer implements DedicatedServerModInitializer {
    public static final String MOD_ID = "simplybetter-core";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    /** singleton global instance accessible via db()*/
    private static DatabaseManager DB;

    /** Global singleton accessor
     *  @return the singleton DatabaseManager instance
     * */
    public static DatabaseManager db() {
        return DB;
    }

    @Override
    public void onInitializeServer() {
        LOGGER.info("[{}] Initializing database...", MOD_ID);
        try {
            DB = DatabaseManager.createDefault();
            DB.init();
        } catch (Exception e) {
            LOGGER.error("[{}] Failed to initialize database: {}", MOD_ID, e.getMessage(), e);
            return;
        }
        LOGGER.info("[{}] database initialized.", MOD_ID);

        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            try {
                if (DB != null) {
                    DB.shutdown(Duration.ofSeconds(5));
                    LOGGER.info("[{}] database shut down.", MOD_ID);
                }
            } catch (Exception e) {
                LOGGER.error("[{}] Failed to shut down database: {}", MOD_ID, e.getMessage(), e);
            }
        });

        LOGGER.info("[{}] Initializing modules", MOD_ID);
        initializeAllCrudManagers();
        LOGGER.info("[{}] Modules initialized", MOD_ID);
    }

    @Getter private static AccountsCrudManager accountsCrudManager;
    @Getter private static AfksCrudManager afksCrudManager;
    @Getter private static AuditLogsCrudManager auditLogsCrudManager;
    @Getter private static BackLocationsCrudManager backLocationsCrudManager;
    @Getter private static BansCrudManager bansCrudManager;
    @Getter private static BansIpCrudManager bansIpCrudManager;
    @Getter private static ChatLogsCrudManager chatLogsCrudManager;
    @Getter private static HomesCrudManager homesCrudManager;
    @Getter private static IgnoresCrudManager ignoresCrudManager;
    @Getter private static JailsCrudManager jailsCrudManager;
    @Getter private static JailSanctionsCrudManager jailSanctionsCrudManager;
    @Getter private static KitCooldownsCrudManager kitCooldownsCrudManager;
    @Getter private static KitItemsCrudManager kitItemsCrudManager;
    @Getter private static KitsCrudManager kitsCrudManager;
    @Getter private static MailsCrudManager mailsCrudManager;
    @Getter private static MutesCrudManager mutesCrudManager;
    @Getter private static PlayersCrudManager playersCrudManager;
    @Getter private static PositionsCrudManager positionsCrudManager;
    @Getter private static PrivateChatLogsCrudManager privateChatLogsCrudManager;
    @Getter private static RtpSettingsCrudManager rtpSettingsCrudManager;
    @Getter private static SocialSpysCrudManager socialSpysCrudManager;
    @Getter private static TransactionsCrudManager transactionsCrudManager;
    @Getter private static UserLogsCrudManager userLogsCrudManager;
    @Getter private static WarpsCrudManager warpsCrudManager;
    @Getter private static WorldsCrudManager worldsCrudManager;

    /* Initialize all CRUD managers */
    private void initializeAllCrudManagers() {
        accountsCrudManager = new AccountsCrudManager(DB);
        afksCrudManager = new AfksCrudManager(DB);
        auditLogsCrudManager = new AuditLogsCrudManager(DB);
        backLocationsCrudManager = new BackLocationsCrudManager(DB);
        bansCrudManager = new BansCrudManager(DB);
        bansIpCrudManager = new BansIpCrudManager(DB);
        chatLogsCrudManager = new ChatLogsCrudManager(DB);
        homesCrudManager = new HomesCrudManager(DB);
        ignoresCrudManager = new IgnoresCrudManager(DB);
        jailsCrudManager = new JailsCrudManager(DB);
        jailSanctionsCrudManager = new JailSanctionsCrudManager(DB);
        kitCooldownsCrudManager = new KitCooldownsCrudManager(DB);
        kitItemsCrudManager = new KitItemsCrudManager(DB);
        kitsCrudManager = new KitsCrudManager(DB);
        mailsCrudManager = new MailsCrudManager(DB);
        mutesCrudManager = new MutesCrudManager(DB);
        playersCrudManager = new PlayersCrudManager(DB);
        positionsCrudManager = new PositionsCrudManager(DB);
        privateChatLogsCrudManager = new PrivateChatLogsCrudManager(DB);
        rtpSettingsCrudManager = new RtpSettingsCrudManager(DB);
        socialSpysCrudManager = new SocialSpysCrudManager(DB);
        transactionsCrudManager = new TransactionsCrudManager(DB);
        userLogsCrudManager = new UserLogsCrudManager(DB);
        warpsCrudManager = new WarpsCrudManager(DB, positionsCrudManager);
        worldsCrudManager = new WorldsCrudManager(DB);
    }
}
