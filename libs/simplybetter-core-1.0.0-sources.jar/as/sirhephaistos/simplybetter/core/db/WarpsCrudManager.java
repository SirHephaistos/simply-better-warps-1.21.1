package as.sirhephaistos.simplybetter.core.db;


import as.sirhephaistos.simplybetter.library.AfkDTO;
import as.sirhephaistos.simplybetter.library.BackLocationDTO;
import as.sirhephaistos.simplybetter.library.PositionDTO;
import as.sirhephaistos.simplybetter.library.WarpDTO;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public final class WarpsCrudManager {
    private final DatabaseManager db; // provides connections
    private static PositionsCrudManager positionsCrudManager;

    public WarpsCrudManager(DatabaseManager db, PositionsCrudManager positionsCrudManager) {
        this.db = db;
        WarpsCrudManager.positionsCrudManager = positionsCrudManager;
    }


    // -- Helpers

    /**
     * Privater helper to get a mounted {@link WarpDTO} from a {@link ResultSet}.
     * @param rs the {@link ResultSet}, positioned at the row to map.
     * @return the mapped {@link AfkDTO}.
     * @throws SQLException             on SQL errors coming from jdbc.
     * @throws IllegalArgumentException if rs is null.
     * @throws IllegalStateException    if any non-nullable column is null.
     */
    private static WarpDTO mapWarp(ResultSet rs) throws SQLException {
        if (rs == null) throw new IllegalArgumentException("rs is null");

        final long id = rs.getLong("id");
        if (rs.wasNull()) throw new IllegalStateException("id is null");
        @NotNull final String name = rs.getString("name");
        if (name == null) throw new IllegalStateException("name is null");
        final long positionId = rs.getLong("position_id");
        if (rs.wasNull()) throw new IllegalStateException("position_id is null");
        @Nullable final String createdBy = rs.getString("created_by_uuid");
        @NotNull final String createdAt = rs.getString("created_at");
        if (createdAt == null) throw new IllegalStateException("created_at is null");
        @NotNull final PositionDTO position = positionsCrudManager.getPositionById(positionId).orElseThrow(() -> new IllegalStateException("position with id " + positionId + " does not exist"));
        return new WarpDTO(id, name, position, createdBy, createdAt);
    }

    /**
     * Reformats a string to be used as a warp name.
     * Removes all non-alphanumeric characters and converts to lowercase.
     * @param s the string to reformat.
     * @return the reformatted string.
     * @throws IllegalArgumentException if s is null.
     */
    private static String strReformat(String s) {
        if (s == null) {
            throw new IllegalArgumentException("String is null");
        }
        return s.replaceAll("[^a-zA-Z0-9_]", "").replace(" ", "_").toLowerCase();
    }


    // -- Create

    /**
     * Create a new warp from a {@code name} and a {@link PositionDTO}.
     * @param name string name of the warp (will be reformatted by {@link #strReformat(String)}).
     * @param positionDTO a {@link PositionDTO} representing the position of the warp.
     * @param createdBy {@code playerUUID} who created the warp, or {@code null} if created by the system.
     * @param createdAt timestamp string of when the warp was created.
     * @return the created {@link WarpDTO}.
     * @throws IllegalArgumentException if {@code name} or {@code positionDTO} is null.
     * @throws IllegalStateException if the position could not be created.
     * @throws RuntimeException on SQL errors.
     */
    public WarpDTO createWarp(@NotNull String name, @NotNull PositionDTO positionDTO, @Nullable String createdBy, @Nullable String createdAt) {
        name = strReformat(name);
        if (positionDTO.id() == null) {
            positionDTO = positionsCrudManager.createPosition(positionDTO);
            if (positionDTO.id() == null) {
                throw new IllegalStateException("Failed to create position for warp");
            }
        }
        long id;
        String sql = "INSERT INTO sb_warps (name,  created_at, created_by_uuid, position_id) VALUES (?, ?, ?, ?)";

        try (Connection conn = db.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, name);
            if (createdAt != null) {
                ps.setString(2, createdAt);
            } else {
                ps.setNull(2, java.sql.Types.VARCHAR);
            }
            if (createdBy != null) {
                ps.setString(3, createdBy);
            } else {
                ps.setNull(3, java.sql.Types.VARCHAR);
            }
            ps.setLong(4, positionDTO.id());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (!keys.next()) {
                    throw new RuntimeException("No generated keys");
                }
                id = keys.getLong(1);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to create warp", e);
        }
        return getWarpById(id).orElseThrow(() -> new IllegalStateException("Failed to retrieve created warp with id " + id));
    }

    public WarpDTO createWarp(@NotNull String name,long idPosition, @Nullable String createdBy, @NotNull String createdAt){
        var positionDTO = positionsCrudManager.getPositionById(idPosition).orElseThrow(()->new IllegalArgumentException("Position with id "+idPosition+" does not exist"));
        return createWarp(name,positionDTO,createdBy,createdAt);
    }

    public WarpDTO createWarp(@NotNull String name, @NotNull PositionDTO positionDTO){
        return createWarp(name,positionDTO,null,null);
    }

    public WarpDTO createWarp(@NotNull String name,long idPosition){
        var positionDTO = positionsCrudManager.getPositionById(idPosition).orElseThrow(()->new IllegalArgumentException("Position with id "+idPosition+" does not exist"));
        return createWarp(name,positionDTO,null,null);
    }

    // -- Read

    /**
     * Get a warp by its id.
     * @param id the id of the warp.
     * @return an {@link Optional} containing the {@link WarpDTO} if found, or empty if not found.
     * @throws RuntimeException on SQL errors.
     */
    public Optional<WarpDTO> getWarpById(long id) {
        final String sql = "SELECT id, name, created_at, created_by_uuid, position_id FROM sb_warps WHERE id = ?";
        try (Connection conn = db.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapWarp(rs));
                } else {
                    return Optional.empty();
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to get warp by id=" + id, e);
        }
    }

    /**
     * Get a warp by its name.
     * @param name the name of the warp.
     * @return an {@link Optional} containing the {@link WarpDTO} if found, or empty if not found.
     * @throws RuntimeException on SQL errors.
     */
    public Optional<WarpDTO> getWarpByName(@NotNull String name) {
        name = strReformat(name);
        final String sql = "SELECT id, name, created_at, created_by_uuid, position_id FROM sb_warps WHERE name = ?";
        try (Connection conn = db.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, name);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapWarp(rs));
                } else {
                    return Optional.empty();
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to get warp by name=" + name, e);
        }
    }

    public List<WarpDTO> getAllWarps() {
        final String sql = "SELECT id, name, created_at, created_by_uuid, position_id FROM sb_warps";
        try (Connection conn = db.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            List<WarpDTO> warps = new java.util.ArrayList<>();
            while (rs.next()) {
                warps.add(mapWarp(rs));
            }
            return warps;
        } catch (SQLException e) {
            throw new RuntimeException("Failed to get all warps", e);
        }
    }

    public List<WarpDTO> getAllWarpsPaged(int limit, int offset) {
        final String sql = "SELECT id, name, created_at, created_by_uuid, position_id FROM sb_warps LIMIT ? OFFSET ?";
        try (Connection conn = db.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, limit);
            ps.setInt(2, offset);
            try (ResultSet rs = ps.executeQuery()) {
                List<WarpDTO> warps = new java.util.ArrayList<>();
                while (rs.next()) {
                    warps.add(mapWarp(rs));
                }
                return warps;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to get all warps paged", e);
        }
    }

    public Map<String,@NotNull Long> getWarpsMap(){
        // do a custom query to get name and id only
        final String sql = "SELECT id, name FROM sb_warps";
        try (Connection conn = db.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            return getStringLongMap(rs);
        } catch (SQLException e) {
            throw new RuntimeException("Failed to get warps map", e);
        }
    }

    public Map<String,@NotNull Long> getWarpsMapPaged(int limit, int offset){
        // do a custom query to get name and id only
        final String sql = "SELECT id, name FROM sb_warps LIMIT ? OFFSET ?";
        try (Connection conn = db.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, limit);
            ps.setInt(2, offset);
            try (ResultSet rs = ps.executeQuery()) {
                return getStringLongMap(rs);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to get warps map paged", e);
        }
    }

    @NotNull
    private Map<String, @NotNull Long> getStringLongMap(ResultSet rs) throws SQLException {
        Map<String, Long> warpsMap = new java.util.HashMap<>();
        while (rs.next()) {
            final long id = rs.getLong("id");
            if (rs.wasNull()) throw new IllegalStateException("id is null");
            @NotNull final String name = rs.getString("name");
            if (name == null) throw new IllegalStateException("name is null");
            warpsMap.put(name, id);
        }
        return warpsMap;
    }
    // -- Update

    /**
     * Update the position of a warp.
     * @param warpId      the id of the warp to update.
     * @param newPosition the new {@link PositionDTO} for the warp.
     * @return an {@link Optional} containing the updated {@link WarpDTO} if found, or empty if not found.
     * @throws IllegalArgumentException if {@code newPosition} is null.
     * @throws RuntimeException on SQL errors.
     */
    public Optional<WarpDTO> updateWarpPosition(long warpId, @NotNull PositionDTO newPosition) {
        final Optional<WarpDTO> existingWarpOpt = getWarpById(warpId);
        if (existingWarpOpt.isEmpty()) {
            return Optional.empty();
        }
        final WarpDTO existingWarp = existingWarpOpt.get();
        PositionDTO positionToUpdate;
        if (newPosition.id() == null) {
            positionToUpdate = positionsCrudManager.createPosition(newPosition);
        } else {
            positionToUpdate = newPosition;
        }
        final String sql = "UPDATE sb_warps SET position_id = ? WHERE id = ?";
        try (Connection conn = db.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, positionToUpdate.id());
            ps.setLong(2, warpId);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Failed to update warp position for warp id=" + warpId, e);
        }
        return getWarpById(warpId);
    }

    /**
     * Rename a warp.
     * @param warpId  the id of the warp to rename.
     * @param newName the new name for the warp.
     * @return an {@link Optional} containing the updated {@link WarpDTO} if found, or empty if not found.
     * @throws IllegalArgumentException if {@code newName} is null.
     * @throws RuntimeException on SQL errors.
     */
    public Optional<WarpDTO> renameWarp(long warpId, @NotNull String newName) {
        if (getWarpById(warpId).isEmpty()) {
            throw new IllegalArgumentException("Warp with id " + warpId + " does not exist");
        }
        final String sql = "UPDATE sb_warps SET name = ? WHERE id = ?";
        try (Connection conn = db.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newName);
            ps.setLong(2, warpId);
            final int executed = ps.executeUpdate();
            if (executed == 0) {
                throw new IllegalStateException("No warp renamed with id " + warpId);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to rename warp id=" + warpId, e);
        }
        return getWarpById(warpId);
    }

    // -- Delete

    /**
     * Delete a warp by its id.
     * @param id the id of the warp to delete.
     * @throws IllegalArgumentException if the warp does not exist.
     * @throws RuntimeException on SQL errors.
     */
    public void deleteWarpById(long id) {
        if (getWarpById(id).isEmpty()) {
            throw new IllegalArgumentException("Warp with id " + id + " does not exist");
        }
        final String sql = "DELETE FROM sb_warps WHERE id = ?";
        try (Connection conn = db.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, id);
            final int affected = ps.executeUpdate();
            if (affected == 0) {
                throw new IllegalStateException("No warp deleted with id " + id);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to delete warp by id=" + id, e);
        }
    }

    /**
     * Delete a warp by its name.
     * @param name the name of the warp to delete.
     * @throws IllegalArgumentException if the warp does not exist.
     * @throws RuntimeException on SQL errors.
     */
    public void deleteWarpByName(@NotNull String name) {
        name = strReformat(name);
        final Optional<WarpDTO> warpOpt = getWarpByName(name);
        if (warpOpt.isEmpty()) {
            throw new IllegalArgumentException("Warp with name " + name + " does not exist");
        }
        final String sql = "DELETE FROM sb_warps WHERE name = ?";
        try (Connection conn = db.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, name);
            final int affected = ps.executeUpdate();
            if (affected == 0) {
                throw new IllegalStateException("No warp deleted with name " + name);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to delete warp by name=" + name, e);
        }
    }
}
