package as.sirhephaistos.simplybetter.core.db;

import org.jetbrains.annotations.NotNull;

public final class PlayersCrudManager {
    private final DatabaseManager db;
    public PlayersCrudManager(@NotNull DatabaseManager db) {
        this.db = db;
    }
}
