package as.sirhephaistos.simplybetter.core.db;

import org.jetbrains.annotations.NotNull;

public final class HomesCrudManager {
    private final DatabaseManager db;

    public HomesCrudManager(@NotNull DatabaseManager db) {
        this.db = db;
    }
}
