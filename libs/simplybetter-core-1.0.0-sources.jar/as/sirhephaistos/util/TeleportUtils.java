package as.sirhephaistos.util;

import as.sirhephaistos.simplybetter.library.PositionDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Objects;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2168;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3230;
import net.minecraft.class_5250;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public final class TeleportUtils {
    private static final Logger LOGGER = LoggerFactory.getLogger("simplybetter-teleport");

    private TeleportUtils() {}

    public static int teleportPlayerToPosition(
            class_3222 player,
            PositionDTO position,
            String errorMessage,
            String successMessage,
            class_2168 src
    ) {
        try {
            class_2960 dimId = class_2960.method_12829(position.dimensionId());
            if (dimId == null) {
                LOGGER.error("Invalid dimension ID: {}", position.dimensionId());
                class_5250 text = class_2561.method_43470(errorMessage)
                        .method_10852(class_2561.method_43470("'. Invalid dimension."));
                src.method_9213(text);
                return 0;
            }

            class_5321<class_1937> targetKey = class_5321.method_29179(class_7924.field_41223, dimId);
            class_3218 targetWorld = Objects.requireNonNull(player.method_5682()).method_3847(targetKey);
            if (targetWorld == null) {
                LOGGER.error("Target world is null for dimension: {}", dimId);
                class_5250 text = class_2561.method_43470(errorMessage)
                        .method_10852(class_2561.method_43470("'. World not found."));
                src.method_9213(text);
                return 0;
            }

            class_2338 targetPos = class_2338.method_49637(position.x(), position.y(), position.z());
            class_1923 chunkPos = new class_1923(targetPos);
            targetWorld.method_14178().method_17297(class_3230.field_19347, chunkPos, 1, player.method_5628());
            targetWorld.method_8497(chunkPos.field_9181, chunkPos.field_9180);
            player.method_14251(targetWorld, position.x(), position.y(), position.z(), position.yRot(), position.xRot());

            class_5250 text = class_2561.method_43470(successMessage);
            src.method_9226(() -> text, false);
            return 1;
        } catch (Exception e) {
            LOGGER.error("Failed to teleport player to position: {}", position, e);
            class_5250 text = class_2561.method_43470(errorMessage)
                    .method_10852(class_2561.method_43470("'. Please try again later."));
            src.method_9213(text);
            return 0;
        }
    }
}